jQuery(document).ready(function($) {
    $('#sppp-update-plugin').on('click', function(e) {
        e.preventDefault();

        var pluginUrl = $(this).data('url');

        $.ajax({
            url: spppUpdate.ajax_url,
            method: 'POST',
            data: {
                action: 'sppp_update_plugin',
                plugin_url: pluginUrl,
                nonce: spppUpdate.nonce
            },
            beforeSend: function() {
                $('#sppp-update-plugin').text('Atualizando...');
            },
            success: function(response) {
                if (response.success) {
                    $('#sppp-update-plugin').text('Plugin atualizado com sucesso.');
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    $('#sppp-update-plugin').text('Erro na atualização.');
                    console.log(response.data);
                }
            },
            error: function(xhr, status, error) {
                $('#sppp-update-plugin').text('Erro na atualização.');
                console.log(error);
            }
        });
    });
});
