jQuery(document).ready(function($) {
    $('.sppp-update-plugin').on('click', function(e) {
        e.preventDefault();

        var pluginUrl = $(this).data('url');
        var pluginName = $(this).data('name');

        $.ajax({
            type: 'POST',
            url: spppUpdate.ajax_url,
            data: {
                action: 'sppp_update_plugin',
                plugin_url: pluginUrl,
                plugin_name: pluginName,
                nonce: spppUpdate.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('Plugin instalado ou atualizado com sucesso.');
                } else {
                    alert('Erro ao instalar o plugin: ' + response.data);
                }
            },
            error: function(xhr, status, error) {
                alert('Erro ao fazer a solicitação AJAX: ' + error);
            }
        });
    });
});
