jQuery(document).ready(function($) {
    $(document).on('click', '.sppp-install-plugin', function(e) {
        e.preventDefault();

        var pluginUrl = $(this).data('url');
        var pluginName = $(this).data('name');

        $.ajax({
            url: spppUpdate.ajax_url,
            method: 'POST',
            data: {
                action: 'sppp_prepare_install_plugin',
                plugin_url: pluginUrl,
                plugin_name: pluginName,
                nonce: spppUpdate.nonce
            },
            beforeSend: function() {
                $('.sppp-install-plugin[data-name="' + pluginName + '"]').text('Atualizando...');
            },
            success: function(response) {
                if (response.success) {
                    $('.sppp-install-plugin[data-name="' + pluginName + '"]').text('Plugin atualizado com sucesso.');
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    $('.sppp-install-plugin[data-name="' + pluginName + '"]').text('Erro na atualização.');
                    console.log(response.data);
                }
            },
            error: function(xhr, status, error) {
                $('.sppp-install-plugin[data-name="' + pluginName + '"]').text('Erro na atualização.');
                console.log(error);
            }
        });
    });
});
