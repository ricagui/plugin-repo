<?php
/*
Plugin Name: Super Pack Plugins Pro
Author: Ricardo Mendes
Version: 1.1.0
Description: Instale e atualize plugins diretamente. Após ativar, verifique no menu lateral esquerdo o nome S P Plugins Pro.
*/

// Chave de criptografia gerada anteriormente
$part1 = '7c7bc7319a';
$part2 = '2fa6cf72cd';
$part3 = '68e87c2ab32b';

// Combinar as partes para formar a chave completa
$key = $part1 . $part2 . $part3;

// URL criptografada obtida do script encrypt.php
$encryptedUrl = 'U0e+grGpz+38T7t8UDOINThPSVRsV2FDSThJK3I2SnJlQ0c3T0daTFlNR1NGeWJIc2kyTlZoZzBCdUphWHI3U0NaeFdMeDdsZ3JvMFNhckZzL1JkcVFRWkhjV0tnZmtNQ2J6bWVjWFBuOTF4L1JaZG1WTGxVMUJZY0ZESWdHRVY0WGYwZkdaU1J1V3JmNUVa'; // Substitua pela URL criptografada gerada

// Método de criptografia e opções
$method = 'aes-256-cbc';
$encryptedData = base64_decode($encryptedUrl);
$ivLength = openssl_cipher_iv_length($method);
$iv = substr($encryptedData, 0, $ivLength);
$ciphertext = substr($encryptedData, $ivLength);

// Descriptografar a URL
$plugins_url = openssl_decrypt($ciphertext, $method, hex2bin($key), 0, $iv);

// Verifique se a URL foi descriptografada corretamente
error_log('URL descriptografada: ' . $plugins_url);

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Admin menu
add_action('admin_menu', 'sppp_create_menu');

function sppp_create_menu() {
    add_menu_page(
        'S P Plugins Pro',
        'S P Plugins Pro',
        'manage_options',
        'super-pack-plugins-pro',
        'sppp_settings_page'
    );
}

function sppp_settings_page() {
    ?>
    <div class="wrap">
        <h1>Super Pack Plugins Pro</h1>
        <p>Os plugins serão atualizados automaticamente conforme a lista definida remotamente.</p>
        <?php sppp_installation_table(); ?>
        <?php sppp_display_jet_engine_messages(); ?>
    </div>
    <?php
}

function sppp_installation_table() {
    $plugins = sppp_get_remote_plugins();

    if (!empty($plugins)) {
        echo '<h2>Plugins disponíveis para instalação</h2>';
        echo '<table class="widefat fixed" cellspacing="0">
                <thead>
                    <tr>
                        <th class="manage-column">Plugin</th>
                        <th class="manage-column">Ação</th>
                    </tr>
                </thead>
                <tbody>';
        foreach ($plugins as $name => $data) {
            // Ignorar o plugin Super Pack Plugins Pro na lista de instalação
            if ($name === 'Super Pack Plugins Pro') {
                continue;
            }
            if (isset($data['url'])) {
                $url = $data['url'];
                echo '<tr>
                        <td>' . esc_html($name) . '</td>
                        <td><a href="' . esc_url(admin_url('plugins.php?action=sppp_update_plugin&plugin_name=' . urlencode($name) . '&plugin_url=' . urlencode($url))) . '">Instalar</a></td>
                      </tr>';
            }
        }
        echo '</tbody></table>';
    }
}

function sppp_get_remote_plugins() {
    global $plugins_url;
    $response = wp_remote_get($plugins_url);
    if (is_wp_error($response)) {
        error_log('Erro ao obter plugins remotos: ' . $response->get_error_message());
        return [];
    }

    $body = wp_remote_retrieve_body($response);
    $plugins = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        error_log('Erro ao decodificar JSON: ' . json_last_error_msg());
        return [];
    }

    error_log('Plugins remotos: ' . print_r($plugins, true));
    return $plugins;
}

function sppp_display_jet_engine_messages() {
    $plugins = sppp_get_remote_plugins();
    if (isset($plugins['Jet Engine']['messages']) && is_array($plugins['Jet Engine']['messages'])) {
        foreach ($plugins['Jet Engine']['messages'] as $message) {
            $message = esc_html($message);
            echo '<div class="notice notice-success"><p>' . $message . '</p></div>';
        }
    }
}

add_action('admin_init', 'sppp_register_settings');

function sppp_register_settings() {
    register_setting('sppp-settings-group', 'sppp_email');
}

// Função para baixar e instalar o plugin
function sppp_download_and_install_plugin($plugin_name, $url) {
    error_log("Iniciando download do plugin: $plugin_name de $url");
    
    $response = wp_remote_get($url, array('timeout' => 300));
    if (is_wp_error($response)) {
        error_log('Erro ao baixar o plugin: ' . $response->get_error_message());
        return 'Erro ao baixar o plugin: ' . $response->get_error_message();
    }

    $content_type = wp_remote_retrieve_header($response, 'content-type');
    if (strpos($content_type, 'zip') === false) {
        $error_message = 'O arquivo baixado não é um arquivo ZIP válido. Conteúdo: ' . substr(wp_remote_retrieve_body($response), 0, 100);
        error_log($error_message);
        return $error_message;
    }

    $file = wp_tempnam($url);
    if (!$file) {
        $error_message = 'Erro ao criar arquivo temporário.';
        error_log($error_message);
        return $error_message;
    }

    $body = wp_remote_retrieve_body($response);
    if (!file_put_contents($file, $body)) {
        $error_message = 'Erro ao salvar o plugin no arquivo temporário.';
        error_log($error_message);
        return $error_message;
    }

    if (!class_exists('ZipArchive')) {
        $error_message = 'A extensão PHP ZipArchive não está disponível.';
        error_log($error_message);
        return $error_message;
    }
    
    $zip = new ZipArchive;
    if ($zip->open($file) !== true) {
        $error_message = 'Erro ao abrir o arquivo ZIP baixado.';
        error_log($error_message);
        return $error_message;
    }
    $zip->close();

    $plugin_dir = WP_PLUGIN_DIR . '/' . strtolower(str_replace(' ', '-', $plugin_name));
    if (is_dir($plugin_dir)) {
        error_log("Removendo diretório existente do plugin: $plugin_dir");
        sppp_remove_directory($plugin_dir);
    }

    include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    include_once ABSPATH . 'wp-admin/includes/file.php';
    include_once ABSPATH . 'wp-admin/includes/misc.php';
    include_once ABSPATH . 'wp-admin/includes/plugin.php';

    $upgrader = new Plugin_Upgrader();
    error_log("Instalando plugin usando Plugin_Upgrader...");
    $result = $upgrader->install($file);

    unlink($file);

    if (is_wp_error($result)) {
        $error_message = 'Erro ao instalar o plugin: ' . $result->get_error_message();
        error_log($error_message);
        return $error_message;
    }

    error_log('Plugin instalado ou atualizado com sucesso.');
    return true;
}

function sppp_remove_directory($dir) {
    if (!file_exists($dir)) {
        return true;
    }

    if (!is_dir($dir)) {
        return unlink($dir);
    }

    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }

        if (!sppp_remove_directory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }

    return rmdir($dir);
}

// Verificar e adicionar link de atualização para Super Pack Plugins Pro
add_action('admin_init', 'sppp_check_for_update');

function sppp_check_for_update() {
    $plugins = sppp_get_remote_plugins();

    if (isset($plugins['Super Pack Plugins Pro'])) {
        $remote_version = $plugins['Super Pack Plugins Pro']['version'];
        $plugin_data = get_plugin_data(__FILE__);

        error_log('Versão local: ' . $plugin_data['Version']);
        error_log('Versão remota: ' . $remote_version);

        if (version_compare($plugin_data['Version'], $remote_version, '<')) {
            add_filter('plugin_action_links_' . plugin_basename(__FILE__), 'sppp_plugin_action_links');
        }
    } else {
        error_log('Super Pack Plugins Pro não encontrado na lista de plugins remotos.');
    }
}

function sppp_plugin_action_links($links) {
    $plugins = sppp_get_remote_plugins();
    if (isset($plugins['Super Pack Plugins Pro'])) {
        $update_url = $plugins['Super Pack Plugins Pro']['url'];

        $links[] = '<a href="' . esc_url(admin_url('plugins.php?action=sppp_update_plugin&plugin_name=' . urlencode('Super Pack Plugins Pro') . '&plugin_url=' . urlencode($update_url))) . '">Atualizar com Super Pack Plugins Pro</a>';
    }
    return $links;
}

add_action('admin_action_sppp_update_plugin', 'sppp_handle_update_plugin');
function sppp_handle_update_plugin() {
    if (!current_user_can('update_plugins')) {
        wp_die('Você não tem permissão para atualizar plugins.');
    }

    $plugin_name = isset($_GET['plugin_name']) ? sanitize_text_field($_GET['plugin_name']) : '';
    $plugin_url = isset($_GET['plugin_url']) ? esc_url_raw($_GET['plugin_url']) : '';

    if (empty($plugin_name) || empty($plugin_url)) {
        wp_die('Nome do plugin ou URL do plugin não especificado.');
    }

    // Redirecionar para uma página de atualização temporária
    wp_redirect(admin_url('admin.php?page=sppp_update_plugin&plugin_name=' . urlencode($plugin_name) . '&plugin_url=' . urlencode($plugin_url)));
    exit;
}

add_action('admin_menu', 'sppp_add_update_page');
function sppp_add_update_page() {
    add_submenu_page(
        null,
        'Atualizando Plugin',
        'Atualizando Plugin',
        'manage_options',
        'sppp_update_plugin',
        'sppp_update_plugin_page'
    );
}

function sppp_update_plugin_page() {
    $plugin_name = isset($_GET['plugin_name']) ? sanitize_text_field($_GET['plugin_name']) : '';
    $plugin_url = isset($_GET['plugin_url']) ? esc_url_raw($_GET['plugin_url']) : '';

    if (empty($plugin_name) || empty($plugin_url)) {
        wp_die('Nome do plugin ou URL do plugin não especificado.');
    }

    // Inicie a saída do buffer
    ob_start();

    $result = sppp_download_and_install_plugin($plugin_name, $plugin_url);

    // Limpe o buffer de saída e encerre-o
    ob_end_clean();

    if ($result === true) {
        echo '<div id="sppp_update_success" style="display: none;"></div>';
    } else {
        echo '<div id="sppp_update_failure" style="display: none;" data-error="' . esc_attr($result) . '"></div>';
    }

    // JavaScript para redirecionar de volta para a página de plugins após um pequeno atraso
    ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function() {
            setTimeout(function() {
                const successDiv = document.getElementById('sppp_update_success');
                const failureDiv = document.getElementById('sppp_update_failure');
                if (successDiv) {
                    window.location.href = '<?php echo admin_url('plugins.php?update=success'); ?>';
                } else if (failureDiv) {
                    const error = failureDiv.getAttribute('data-error');
                    window.location.href = '<?php echo admin_url('plugins.php?update=failure&error='); ?>' + encodeURIComponent(error);
                }
            }, 2000); // Aguarda 2 segundos antes de redirecionar
        });
    </script>
    <?php
}

add_action('admin_notices', 'sppp_admin_notices');
function sppp_admin_notices() {
    if (isset($_GET['update'])) {
        if ($_GET['update'] === 'success') {
            echo '<div class="notice notice-success is-dismissible"><p>Plugin atualizado com sucesso.</p></div>';
        } elseif ($_GET['update'] === 'failure' && isset($_GET['error'])) {
            echo '<div class="notice notice-error is-dismissible"><p>Erro ao atualizar o plugin: ' . esc_html($_GET['error']) . '</p></div>';
        }
    }
}
?>

