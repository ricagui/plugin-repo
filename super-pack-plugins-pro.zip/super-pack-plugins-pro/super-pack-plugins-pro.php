<?php
/*
Plugin Name: Super Pack Plugins Pro
Author: Ricardo Mendes
Version: 1.0.0
Description: Instale e atualize plugins diretamente. Após ativar, verifique no menu lateral esquerdo o nome S P Plugins Pro.
*/

// Chave de criptografia gerada anteriormente
$part1 = '7c7bc7319a';
$part2 = '2fa6cf72cd';
$part3 = '68e87c2ab32b';

// Combinar as partes para formar a chave completa
$key = $part1 . $part2 . $part3;

// URL criptografada obtida do script encrypt.php
$encryptedUrl = 'U0e+grGpz+38T7t8UDOINThPSVRsV2FDSThJK3I2SnJlQ0c3T0daTFlNR1NGeWJIc2kyTlZoZzBCdUphWHI3U0NaeFdMeDdsZ3JvMFNhckZzL1JkcVFRWkhjV0tnZmtNQ2J6bWVjWFBuOTF4L1JaZG1WTGxVMUJZY0ZESWdHRVY0WGYwZkdaU1J1V3JmNUVa'; // Substitua pela URL criptografada gerada

// Método de criptografia e opções
$method = 'aes-256-cbc';
$encryptedData = base64_decode($encryptedUrl);
$ivLength = openssl_cipher_iv_length($method);
$iv = substr($encryptedData, 0, $ivLength);
$ciphertext = substr($encryptedData, $ivLength);

// Descriptografar a URL
$plugins_url = openssl_decrypt($ciphertext, $method, hex2bin($key), 0, $iv);

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Admin menu
add_action('admin_menu', 'sppp_create_menu');

function sppp_create_menu() {
    add_menu_page(
        'S P Plugins Pro',
        'S P Plugins Pro',
        'manage_options',
        'super-pack-plugins-pro',
        'sppp_settings_page'
    );
}

function sppp_settings_page() {
    ?>
    <div class="wrap">
        <h1>Super Pack Plugins Pro</h1>
        <p>Os plugins serão atualizados automaticamente conforme a lista definida remotamente.</p>
        <?php sppp_installation_table(); ?>
        <?php sppp_display_jet_engine_messages(); ?>
    </div>
    <?php
}

function sppp_installation_table() {
    $plugins = sppp_get_remote_plugins();

    if (!empty($plugins)) {
        echo '<h2>Plugins disponíveis para instalação</h2>';
        echo '<table class="widefat fixed" cellspacing="0">
                <thead>
                    <tr>
                        <th class="manage-column">Plugin</th>
                        <th class="manage-column">Ação</th>
                    </tr>
                </thead>
                <tbody>';
        foreach ($plugins as $name => $data) {
            if (isset($data['url'])) {
                $url = $data['url'];
                echo '<tr>
                        <td>' . esc_html($name) . '</td>
                        <td><a href="#" class="sppp-install-plugin" data-url="' . esc_url($url) . '" data-name="' . esc_attr($name) . '">Instalar</a></td>
                      </tr>';
            }
        }
        echo '</tbody></table>';
    }
}

function sppp_get_remote_plugins() {
    global $plugins_url;
    $response = wp_remote_get($plugins_url);
    if (is_wp_error($response)) {
        return [];
    }

    $body = wp_remote_retrieve_body($response);
    $plugins = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        return [];
    }

    return $plugins;
}

function sppp_display_jet_engine_messages() {
    $plugins = sppp_get_remote_plugins();
    if (isset($plugins['Jet Engine']['messages']) && is_array($plugins['Jet Engine']['messages'])) {
        foreach ($plugins['Jet Engine']['messages'] as $message) {
            $message = esc_html($message);
            echo '<div class="notice notice-success"><p>' . $message . '</p></div>';
        }
    }
}

add_action('admin_init', 'sppp_register_settings');

function sppp_register_settings() {
    register_setting('sppp-settings-group', 'sppp_email');
}

// Função AJAX para preparar a instalação do plugin
add_action('wp_ajax_sppp_prepare_install_plugin', 'sppp_prepare_install_plugin');
function sppp_prepare_install_plugin() {
    check_ajax_referer('sppp_update_nonce', 'nonce');

    if (!isset($_POST['plugin_url']) || !isset($_POST['plugin_name'])) {
        wp_send_json_error('URL do plugin ou nome do plugin não especificado.');
    }

    $url = esc_url_raw($_POST['plugin_url']);
    $name = sanitize_text_field($_POST['plugin_name']);
    update_option('sppp_plugin_install_url', $url);
    update_option('sppp_plugin_install_name', $name);

    if (sppp_download_and_install_plugin($name, $url)) {
        wp_send_json_success('Plugin instalado ou atualizado com sucesso.');
    } else {
        wp_send_json_error('Erro ao instalar o plugin.');
    }
}

// Função para instalar o plugin
function sppp_download_and_install_plugin($plugin_name, $url) {
    $response = wp_remote_get($url, array('timeout' => 300));

    if (is_wp_error($response)) {
        error_log('Erro ao baixar o plugin: ' . $response->get_error_message());
        return false;
    }

    $content_type = wp_remote_retrieve_header($response, 'content-type');
    if (strpos($content_type, 'zip') === false) {
        error_log('O arquivo baixado não é um arquivo ZIP válido. Conteúdo: ' . substr(wp_remote_retrieve_body($response), 0, 100));
        return false;
    }

    $file = wp_tempnam($url);
    if (!$file) {
        error_log('Erro ao criar arquivo temporário.');
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    if (!file_put_contents($file, $body)) {
        error_log('Erro ao salvar o plugin.');
        return false;
    }

    if (!class_exists('ZipArchive')) {
        error_log('A extensão PHP ZipArchive não está disponível.');
        return false;
    }
        $zip = new ZipArchive;
    if ($zip->open($file) !== true) {
        error_log('O arquivo baixado não é um arquivo ZIP válido.');
        return false;
    }
    $zip->close();

    $plugin_dir = WP_PLUGIN_DIR . '/' . strtolower(str_replace(' ', '-', $plugin_name));
    if (is_dir($plugin_dir)) {
        sppp_remove_directory($plugin_dir);
    }

    include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    include_once ABSPATH . 'wp-admin/includes/file.php';
    include_once ABSPATH . 'wp-admin/includes/misc.php';
    include_once ABSPATH . 'wp-admin/includes/plugin.php';

    $upgrader = new Plugin_Upgrader();
    $result = $upgrader->install($file);

    unlink($file);

    if (is_wp_error($result)) {
        error_log('Erro ao instalar o plugin: ' . $result->get_error_message());
        return false;
    }

    return true;
}

function sppp_remove_directory($dir) {
    if (!file_exists($dir)) {
        return true;
    }

    if (!is_dir($dir)) {
        return unlink($dir);
    }

    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }

        if (!sppp_remove_directory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }

    return rmdir($dir);
}

// Verificar e adicionar link de atualização para Super Pack Plugins Pro
add_action('admin_init', 'sppp_check_for_update');

function sppp_check_for_update() {
    $plugins = sppp_get_remote_plugins();

    if (isset($plugins['Super Pack Plugins Pro'])) {
        $remote_version = $plugins['Super Pack Plugins Pro']['version'];
        $plugin_data = get_plugin_data(__FILE__);

        if (version_compare($plugin_data['Version'], $remote_version, '<')) {
            add_filter('plugin_action_links_super-pack-plugins-pro/super-pack-plugins-pro.php', 'sppp_plugin_action_links');
        }
    }
}

function sppp_plugin_action_links($links) {
    $plugins = sppp_get_remote_plugins();
    $update_url = $plugins['Super Pack Plugins Pro']['url'];

    $links[] = '<a href="#" class="sppp-install-plugin" data-url="' . esc_url($update_url) . '" data-name="Super Pack Plugins Pro">Atualizar com Super Pack Plugins Pro</a>';
    return $links;
}

add_action('admin_enqueue_scripts', 'sppp_enqueue_scripts');
function sppp_enqueue_scripts() {
    wp_enqueue_script('sppp-update-script', plugin_dir_url(__FILE__) . 'sppp-update.js', array('jquery'), null, true);
    wp_localize_script('sppp-update-script', 'spppUpdate', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('sppp_update_nonce')
    ));
}

add_action('wp_ajax_sppp_update_plugin', 'sppp_ajax_update_plugin');
function sppp_ajax_update_plugin() {
    check_ajax_referer('sppp_update_nonce', 'nonce');

    if (!isset($_POST['plugin_url']) || !isset($_POST['plugin_name'])) {
        wp_send_json_error('URL do plugin ou nome do plugin não especificado.');
    }

    $url = esc_url_raw($_POST['plugin_url']);
    $name = sanitize_text_field($_POST['plugin_name']);
    if (sppp_download_and_install_plugin($name, $url)) {
        wp_send_json_success('Plugin instalado ou atualizado com sucesso.');
    } else {
        wp_send_json_error('Erro ao instalar o plugin.');
    }
}

