<?php
/*
Plugin Name: Super Pack Plugins Pro
Author: Ricardo Mendes
Version: 1.0.0
Description: Instale e atualize plugins diretamente. Após ativar, verifique no menu lateral esquerdo o nome S P Plugins Pro.
*/

// Chave de criptografia gerada anteriormente
$part1 = '7c7bc7319a';
$part2 = '2fa6cf72cd';
$part3 = '68e87c2ab32b';

// Combinar as partes para formar a chave completa
$key = $part1 . $part2 . $part3;

// URL criptografada obtida do script encrypt.php
$encryptedUrl = 'U0e+grGpz+38T7t8UDOINThPSVRsV2FDSThJK3I2SnJlQ0c3T0daTFlNR1NGeWJIc2kyTlZoZzBCdUphWHI3U0NaeFdMeDdsZ3JvMFNhckZzL1JkcVFRWkhjV0tnZmtNQ2J6bWVjWFBuOTF4L1JaZG1WTGxVMUJZY0ZESWdHRVY0WGYwZkdaU1J1V3JmNUVa'; // Substitua pela URL criptografada gerada

// Método de criptografia e opções
$method = 'aes-256-cbc';
$encryptedData = base64_decode($encryptedUrl);
$ivLength = openssl_cipher_iv_length($method);
$iv = substr($encryptedData, 0, $ivLength);
$ciphertext = substr($encryptedData, $ivLength);

// Descriptografar a URL
$plugins_url = openssl_decrypt($ciphertext, $method, hex2bin($key), 0, $iv);

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Admin menu
add_action('admin_menu', 'sppp_create_menu');

function sppp_create_menu() {
    add_menu_page(
        'S P Plugins Pro',
        'S P Plugins Pro',
        'manage_options',
        'super-pack-plugins-pro',
        'sppp_settings_page'
    );
}

function sppp_settings_page() {
    ?>
    <div class="wrap">
        <h1>Super Pack Plugins Pro</h1>
        <p>Os plugins serão atualizados automaticamente conforme a lista definida remotamente.</p>
        <?php sppp_installation_table(); ?>
        <?php sppp_display_jet_engine_messages(); ?>
    </div>
    <?php
}

function sppp_installation_table() {
    $plugins = sppp_get_remote_plugins();

    if (!empty($plugins)) {
        echo '<h2>Plugins disponíveis para instalação</h2>';
        echo '<table class="widefat fixed" cellspacing="0">
                <thead>
                    <tr>
                        <th class="manage-column">Plugin</th>
                        <th class="manage-column">Ação</th>
                    </tr>
                </thead>
                <tbody>';
        foreach ($plugins as $name => $data) {
            if (isset($data['url'])) {
                $url = $data['url'];
                $install_link = esc_url(admin_url('admin-post.php?action=sppp_prepare_install_plugin&plugin_url=' . urlencode($url) . '&plugin_name=' . urlencode($name . '.zip')));
                echo '<tr>
                        <td>' . esc_html($name) . '</td>
                        <td><a href="' . $install_link . '">Instalar</a></td>
                      </tr>';
            }
        }
        echo '</tbody></table>';
    }
}

function sppp_get_remote_plugins() {
    global $plugins_url;
    $response = wp_remote_get($plugins_url);
    if (is_wp_error($response)) {
        return [];
    }

    $body = wp_remote_retrieve_body($response);
    $plugins = json_decode($body, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        return [];
    }

    return $plugins;
}

function sppp_display_jet_engine_messages() {
    $plugins = sppp_get_remote_plugins();
    if (isset($plugins['Jet Engine']['messages']) && is_array($plugins['Jet Engine']['messages'])) {
        foreach ($plugins['Jet Engine']['messages'] as $message) {
            $message = esc_html($message);
            echo '<div class="notice notice-success"><p>' . $message . '</p></div>';
        }
    }
}

add_action('admin_init', 'sppp_register_settings');

function sppp_register_settings() {
    register_setting('sppp-settings-group', 'sppp_email');
}

add_action('admin_post_sppp_prepare_install_plugin', function() {
    if (!isset($_GET['plugin_url']) || !isset($_GET['plugin_name'])) {
        wp_die('URL do plugin ou nome do plugin não especificado.');
    }

    $url = esc_url_raw($_GET['plugin_url']);
    $name = sanitize_text_field($_GET['plugin_name']);
    update_option('sppp_plugin_install_url', $url);
    update_option('sppp_plugin_install_name', $name);

    wp_redirect(admin_url('plugins.php?sppp_confirm_install=1'));
    exit;
});

add_action('admin_notices', function() {
    if (isset($_GET['sppp_confirm_install']) && $_GET['sppp_confirm_install'] == 1) {
        sppp_install_plugin();
    }
});

function sppp_install_plugin() {
    $url = get_option('sppp_plugin_install_url');
    $name = get_option('sppp_plugin_install_name');
    if (!$url || !$name) {
        return;
    }

    $plugin_slug = basename($name, '.zip');
    $plugin_dir = WP_PLUGIN_DIR . '/' . $plugin_slug;

    if (is_dir($plugin_dir)) {
        sppp_remove_directory($plugin_dir);
    }

    delete_option('sppp_plugin_install_url');
    delete_option('sppp_plugin_install_name');

    include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    include_once ABSPATH . 'wp-admin/includes/file.php';
    include_once ABSPATH . 'wp-admin/includes/misc.php';
    include_once ABSPATH . 'wp-admin/includes/plugin.php';

    $email = get_option('sppp_email');
    if (!$email) {
        wp_die('Email não autenticado.');
    }

    $response = wp_remote_get($url, array('timeout' => 300));
    if (is_wp_error($response)) {
        error_log('Erro ao baixar o plugin: ' . $response->get_error_message());
        wp_die('Erro ao baixar o plugin: ' . $response->get_error_message());
    }

    $content_type = wp_remote_retrieve_header($response, 'content-type');
    if (strpos($content_type, 'zip') === false) {
        error_log('O arquivo baixado não é um arquivo ZIP válido. Conteúdo: ' . substr(wp_remote_retrieve_body($response), 0, 100));
        wp_die('O arquivo baixado não é um arquivo ZIP válido. Conteúdo: ' . substr(wp_remote_retrieve_body($response), 0, 100));
    }

    $file = wp_tempnam($url);
    if (!$file) {
        error_log('Erro ao criar arquivo temporário.');
        wp_die('Erro ao criar arquivo temporário.');
    }

    $body = wp_remote_retrieve_body($response);
    if (!file_put_contents($file, $body)) {
        error_log('Erro ao salvar o plugin.');
        wp_die('Erro ao salvar o plugin.');
    }

    if (!class_exists('ZipArchive')) {
        error_log('A extensão PHP ZipArchive não está disponível.');
        wp_die('A extensão PHP ZipArchive não está disponível.');
    }
    $zip = new ZipArchive;
    if ($zip->open($file) !== true) {
        error_log('O arquivo baixado não é um arquivo ZIP válido.');
        wp_die('O arquivo baixado não é um arquivo ZIP válido.');
    }
    $zip->close();

    $upgrader = new Plugin_Upgrader();
    $result = $upgrader->install($file);

    unlink($file);

    if (is_wp_error($result)) {
        error_log('Erro ao instalar o plugin: ' . $result->get_error_message());
        wp_die('Erro ao instalar o plugin: ' . $result->get_error_message());
    } else {
        echo '<div class="updated"><p>Plugin instalado ou atualizado com sucesso! Redirecionando...</p></div>';
    }

    echo '<script>
    setTimeout(function() {
        window.location.href = "' . admin_url('plugins.php') . '";
    }, 3000);
    </script>';
}

function sppp_remove_directory($dir) {
    if (!file_exists($dir)) {
        return true;
    }

    if (!is_dir($dir)) {
        return unlink($dir);
    }

    foreach (scandir($dir) as $item) {
        if ($item == '.' || $item == '..') {
            continue;
        }

        if (!sppp_remove_directory($dir . DIRECTORY_SEPARATOR . $item)) {
            return false;
        }
    }

    return rmdir($dir);
}

// Verificar e adicionar link de atualização para Super Pack Plugins Pro
add_action('admin_init', 'sppp_check_for_update');

function sppp_check_for_update() {
    $plugins = sppp_get_remote_plugins();

    if (isset($plugins['Super Pack Plugins Pro'])) {
        $remote_version = $plugins['Super Pack Plugins Pro']['version'];
        $plugin_data = get_plugin_data(__FILE__);

        if (version_compare($plugin_data['Version'], $remote_version, '<')) {
            add_action('admin_notices', 'sppp_update_notice');
        }
    }
}

function sppp_update_notice() {
    $plugins = sppp_get_remote_plugins();
    $update_url = $plugins['Super Pack Plugins Pro']['url'];

    echo '<div class="notice notice-warning is-dismissible">
        <p>Uma nova versão do <strong>Super Pack Plugins Pro</strong> está disponível. <a href="' . esc_url(admin_url('admin-post.php?action=sppp_update_plugin&plugin_url=' . urlencode($update_url))) . '">Clique aqui para atualizar</a>.</p>
    </div>';
}

add_action('admin_post_sppp_update_plugin', function() {
    if (!isset($_GET['plugin_url'])) {
        wp_die('URL do plugin não especificado.');
    }

    $url = esc_url_raw($_GET['plugin_url']);
    sppp_download_and_install_plugin('super-pack-plugins-pro', $url);

    wp_redirect(admin_url('plugins.php?plugin_status=all'));
    exit;
});

function sppp_download_and_install_plugin($plugin_name, $url) {
    $response = wp_remote_get($url, array('timeout' => 300));

    if (is_wp_error($response)) {
        error_log('Erro ao baixar o plugin: ' . $response->get_error_message());
        return false;
    }

    $content_type = wp_remote_retrieve_header($response, 'content-type');
    if (strpos($content_type, 'zip') === false) {
        error_log('O arquivo baixado não é um arquivo ZIP válido. Conteúdo: ' . substr(wp_remote_retrieve_body($response), 0, 100));
        return false;
    }

    $file = wp_tempnam($url);
    if (!$file) {
        error_log('Erro ao criar arquivo temporário.');
        return false;
    }

    $body = wp_remote_retrieve_body($response);
    if (!file_put_contents($file, $body)) {
        error_log('Erro ao salvar o plugin.');
        return false;
    }

    if (!class_exists('ZipArchive')) {
        error_log('A extensão PHP ZipArchive não está disponível.');
        return false;
    }
    $zip = new ZipArchive;
    if ($zip->open($file) !== true) {
        error_log('O arquivo baixado não é um arquivo ZIP válido.');
        return false;
    }
    $zip->close();

    $plugin_dir = WP_PLUGIN_DIR . '/' . strtolower(str_replace(' ', '-', $plugin_name));
    if (is_dir($plugin_dir)) {
        sppp_remove_directory($plugin_dir);
    }

    include_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    include_once ABSPATH . 'wp-admin/includes/file.php';
    include_once ABSPATH . 'wp-admin/includes/misc.php';
    include_once ABSPATH . 'wp-admin/includes/plugin.php';

    $upgrader = new Plugin_Upgrader();
    $result = $upgrader->install($file);

    unlink($file);

    if (is_wp_error($result)) {
        error_log('Erro ao instalar o plugin: ' . $result->get_error_message());
        return false;
    }

    return true;
}
